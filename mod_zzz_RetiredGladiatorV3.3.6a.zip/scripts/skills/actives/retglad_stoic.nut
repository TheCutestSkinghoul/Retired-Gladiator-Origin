this.retglad_stoic <- this.inherit("scripts/skills/skill", {
	m = {},
	function create()
	{
		this.m.ID = "actives.retglad_stoic";
		this.m.Name = "Stoic";
		this.m.Description = "Activate to reduce incoming damage andnegative effect durations by 1 turn. Be unaffected by fresh injuries for one turn.";
		this.m.Icon = "ui/perks/perk_stoic.png";
		this.m.IconDisabled = "ui/perks/perk_stoic_bw.png";
		this.m.Overlay = "perk_stoic_active";
		this.m.SoundOnUse = [
			"sounds/combat/indomitable_01.wav", //Change later?
			"sounds/combat/indomitable_02.wav"
		];
		this.m.Type = this.Const.SkillType.Active;
		this.m.Order = this.Const.SkillOrder.Any;
		this.m.IsSerialized = false;
		this.m.IsActive = true;
		this.m.IsTargeted = false;
		this.m.IsStacking = false;
		this.m.IsAttack = false;
		this.m.ActionPointCost = 2;
		this.m.FatigueCost = 20;
		this.m.MinRange = 0;
		this.m.MaxRange = 0;
	}

	function getTooltip()
	{
		return [
			{
				id = 1,
				type = "title",
				text = this.getName()
			},
			{
				id = 2,
				type = "description",
				text = this.getDescription()
			},
			{
				id = 3,
				type = "text",
				text = this.getCostString()
			},
			{
				id = 6,
				type = "text",
				icon = "ui/icons/special.png",
				text = "Receives only [color=" + this.Const.UI.Color.PositiveValue + "]40%[/color] of any damage"
			},
			{
				id = 6,
				type = "text",
				icon = "ui/icons/special.png",
				text = "[color=" + this.Const.UI.Color.PositiveValue + "]Is not affected by injuries[/color]"
			},
			{
				id = 6,
				type = "text",
				icon = "ui/icons/special.png",
				text = "[color=" + this.Const.UI.Color.PositiveValue + "]Reduces all negative effect durations by 1 turn[/color]"
			}
		];
	}

	function isUsable()
	{
		return this.skill.isUsable() && !this.getContainer().hasSkill("effects.retglad_stoic");
	}

	function onVerifyTarget( _originTile, _targetTile )
	{
		return true;
	}

	function onUse( _user, _targetTile )
	{
		if (!this.getContainer().hasSkill("effects.retglad_stoic"))
		{
			this.m.Container.add(this.new("scripts/skills/effects/retglad_stoic_effect"));
			return true;
		}

		return false;
	}

});

