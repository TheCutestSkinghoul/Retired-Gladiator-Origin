this.pit_fighter_background <- this.inherit("scripts/skills/backgrounds/character_background", {
	m = {},
	function create()
	{
		this.character_background.create(); //—
		this.m.ID = "background.pit_fighter";
		this.m.Name = "Pit Fighter";
		this.m.Icon = "ui/backgrounds/background_pitfighter.png";
		this.m.BackgroundDescription = "Pit fighters are especially brutal — often the unlucky slaves that are hand picked with the chance of becoming gladiators and by extension, paying their way to freedom.";
		this.m.GoodEnding = "%name% had an identity crisis after you left the company, you were a positive force in %their% life and it took them months to fully grasp your departure. Eventually they founded a legitimate gladiator school, who took in slaves and the downtrodden who wnated to fight for a better life. Their school would become the talk of the land and would attract high and lowborn alike.";
		this.m.BadEnding = "%name% was destined to die — that much was clear. However how they would die came as a surprise to many. After you left, the proud pit fighter finally let go of all the horrors they had seen so far, deciding to take their own life rather than remain in this world. %name% was used to bending rather than breaking, but the further the bend — the greater the snap.";
		this.m.HiringCost = 10000000000;
		this.m.DailyCost = 28;
		this.m.Excluded = [
			"trait.gluttonous",
			"trait.lucky",
			"trait.cocky",
			"trait.fat",
			"trait.fearless",
			"trait.drunkard",
			"trait.determined",
			"trait.greedy",
			"trait.hate_undead",
			"trait.hate_greenskins",
			"trait.light",
			"trait.slack"
		];
		this.m.Titles = [
			"the Enslaved",
			"the Prisoner",
			"the Unlucky",
			"the Indebted",
			"the Unfree",
			"the Criminal",
			"the Obedient",
			"the Shackled",
			"the Bound"
		];
		if (this.Math.rand(1, 2))
		{
			this.m.Bodies = this.Const.Bodies.Gladiator;
			this.m.Faces = this.Const.Faces.SouthernMale;
			this.m.Hairs = this.Const.Hair.SouthernMale;
			this.m.HairColors = this.Const.HairColors.Southern;
			this.m.Beards = this.Const.Beards.Southern;
			this.m.BeardChance = 60;
			this.m.Ethnicity = 1;
		}
		else
		{
			this.m.Bodies = this.Const.Bodies.AfricanGladiator;
			this.m.Faces = this.Const.Faces.AfricanMale;
			this.m.Hairs = this.Const.Hair.SouthernMale;
			this.m.HairColors = this.Const.HairColors.African;
			this.m.Beards = this.Const.Beards.Southern;
			this.m.BeardChance = 60;
			this.m.Ethnicity = 2;
		}

		this.m.Names = this.Const.Strings.SouthernNames;
		this.m.LastNames = this.Const.Strings.SouthernNamesLast;
		this.m.Level = 3
		this.m.BackgroundType = this.Const.BackgroundType.Combat;
		this.m.Modifiers.ArmorParts = this.Const.LegendMod.ResourceModifiers.ArmorParts[1];
		this.m.Modifiers.Salvage = this.Const.LegendMod.ResourceModifiers.Salvage[1];
		this.m.Modifiers.Training = this.Const.LegendMod.ResourceModifiers.Training[3];
		this.m.Modifiers.Stash = this.Const.LegendMod.ResourceModifiers.Stash[2];
		this.m.Modifiers.Hunting = this.Const.LegendMod.ResourceModifiers.Hunting[1];
		this.m.Modifiers.Terrain =  [
				0.0, // ?
				0.0, //ocean
				0.0, //plains
				0.0, //swamp
				0.01, //hills
				0.01, //forest
				0.01, //forest
				0.0, //forest_leaves
				0.0, //autumn_forest
				0.01, //mountains
				0.0, // ?
				0.01, //farmland
				0.0, // snow
				0.0, // badlands
				0.0, //highlands
				0.0, //stepps
				0.0, //ocean
				0.01, //desert
				0.01 //oasis
			];
		this.m.PerkTreeDynamic = {
			Weapon = [
				this.Const.Perks.PolearmTree,
				this.Const.Perks.SwordTree,
				this.Const.Perks.MaceTree,
				this.Const.Perks.CleaverTree,
				this.Const.Perks.ThrowingTree,
				this.Const.Perks.DaggerTree,
				this.Const.Perks.ShieldTree,
				this.Const.Perks.FistsTree
			],
			Defense = [
				this.Const.Perks.HeavyArmorTree,
				this.Const.Perks.MediumArmorTree
			],
			Traits = [
				this.Const.Perks.ViciousTree,
				this.Const.Perks.SturdyTree,
				this.Const.Perks.IndestructibleTree,
				this.Const.Perks.AgileTree,
				this.Const.Perks.LargeTree,
				this.Const.Perks.FitTree
			],
			Enemy = [
				this.Const.Perks.BeastTree			
			],
			Class = [
				this.Const.Perks.BeastClassTree
			],
			Magic = []
		}
	}
		
	function setGender( _gender = -1 )
	{
		if (_gender == -1) _gender = ::Legends.Mod.ModSettings.getSetting("GenderEquality").getValue() == "Disabled" ? 0 : ::Math.rand(0, 1);

		if (_gender != 1) return;
		if (this.m.Ethnicity == 1)
		{
			this.m.Faces = this.Const.Faces.SouthernFemale;
			this.m.Hairs = this.Const.Hair.SouthernFemale;
			this.m.HairColors = this.Const.HairColors.Young;
			this.m.Bodies = this.Const.Bodies.SouthernFemaleMuscular;
		}
		else
		{
			this.m.Faces = this.Const.Faces.AfricanFemale;
			this.m.Hairs = this.Const.Hair.SouthernFemale;
			this.m.HairColors = this.Const.HairColors.African;
			this.m.Bodies = this.Const.Bodies.AfricanFemaleMuscular;
		}
		
		this.m.Beards = null;
		this.m.BeardChance = 0;
		this.addBackgroundType(this.Const.BackgroundType.Female);
	}

	function onBuildDescription()
	{
		if(this.isBackgroundType(this.Const.BackgroundType.Female)) //—
		{

		return "{%name%\'s father was a well known artist and engineer. One with a fierce drinking habit to boot. | %name%\'s background is partly a mystery — some say they were a bandit who was related to a local prince while others simply claim she was a thief. | %name% has had a hard childhood and eventually found herself sold to a much older man by her father. Based on her scars and temperament it went about as well as you could\'ve expected. | %name% is fabled to have once been a princess — however, events involving another woman found her cast into the deepest, darkest hole her family could find.} {Ever since she has been fighting and surviving in the area — sometimes in full armour and sometimes with nothing at all. She remains a slave to a master she has never met or heard the name of. | At some point she has had a criminal past, and is fully aware of places and people who could sell you discounted weapons and armour that simply \'fell off the wagon\'. | Scars and marks line her arms, face and legs but none seem to have been painful enough for her to give in and let go. | %name% has become very adept at waiting for long periods and doing nothing. When idle she often counts the stones in a wall or every cobble in the road. Mercenary work suits her well.} {While years of neglect and casual torture dims the spirits and constitution of the average slave, fighters like %name% are always fed better meals and kept in fighting form to not disappoint the crowd. | %name% has little care which master she serves — all are the same to her. But she has made it clear that if anyone were to touch her she\'d cut their eyes out. Which is understandable. | She has no issue fighting beast or man — however the open spaces outside of the area do make her visibly nervous.}";
		}
		else
		{

		return "{%name% had a series of running debts that eventually led them to having to sell his labour to his debtors. Work started simple at first — carry this, go here, and so on. However the difficulty gradually increased until they were stealing from the militia armoury or killing travelers by the roadside. | %name% never knew anything outside of the fighting pits — his mother gave birth to him inside the stockade among the other slaves. Since then he has been taken, trained and educated how to kill or be killed in the arena. | %name%, for some reason known to himself, decided to become a slave on purpose. Specifically causing trouble and demonstrating their fighting skills where his master could see him to be promoted to fighting on his master\'s behalf.} {It has been years since they first started fighting but he has gone from an everyman to a born fighter thanks to the alarming disgregard for his own safety | He has been fighting in the pits for some time now — once choking a hyena with his leg and caving another slave\'s skull in with a rock. | Last season the arena was almost burnt down by a slave revolt. By the time the conscripts had cleared the arena and put out the fire, they noticed %name% was quite comfortable in his bunk daydreaming. Perhaps too foolish to leave or smart enough to know they couldn\'t.} {He liked the arena, but the idea of freedom and his own slice of wealth drew them out from their comfort zone and into the wider world. | While the arena was going well, he had little idea as to an end game and didn\'t expect to make it this far. | The world outside the arena is not what he expected, but like everyone out here he\'ll learn to manage. There are fewer rules out here — after all.}";
		}
	}

	function onSetAppearance()
	{
		local actor = this.getContainer().getActor();
		local tattoo_body = actor.getSprite("tattoo_body");
		local tattoo_head = actor.getSprite("tattoo_head");

		if (this.Math.rand(1, 100) <= 25)
		{
			local body = actor.getSprite("body");
			tattoo_body.setBrush("scar_02_" + body.getBrush().Name);
			tattoo_body.Visible = true;
		}

		if (this.Math.rand(1, 100) <= 30)
		{
			tattoo_head.setBrush("scar_02_head");
			tattoo_head.Visible = true;
		}
	}

	function updateAppearance()
	{
		local actor = this.getContainer().getActor();
		local tattoo_body = actor.getSprite("tattoo_body");

		if (tattoo_body.HasBrush)
		{
			local body = actor.getSprite("body");
			tattoo_body.setBrush("scar_02_" + body.getBrush().Name);
		}
	}

	function onChangeAttributes()
	{
		local c = {
			Hitpoints = [
				5,
				9
			],
			Bravery = [
				-5,
				0
			],
			Stamina = [
				10,
				15
			],
			MeleeSkill = [
				3,
				5
			],
			RangedSkill = [
				3,
				6
			],
			MeleeDefense = [
				-2,
				-4
			],
			RangedDefense = [
				-3,
				-5
			],
			Initiative = [
				5,
				5
			]
		};
		return c;
	}

	function onAdded()
	{
		this.character_background.onAdded();
		local actor = this.getContainer().getActor();
		this.m.Container.add(this.new("scripts/skills/perks/perk_legend_throw_sand"));
	}

	function onAddEquipment()
	{
		local talents = this.getContainer().getActor().getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.RangedSkill] = 2;
		talents[this.Const.Attributes.Hitpoints] = 1;
		this.getContainer().getActor().fillTalentValues(2, true);
		local items = this.getContainer().getActor().getItems();
		local r;

		if (items.hasEmptySlot(this.Const.ItemSlot.Mainhand))
		{
			local weapons = [
				"weapons/oriental/saif",
				"weapons/oriental/nomad_mace",
				"weapons/fighting_axe",
				"weapons/fighting_spear"
			];

			if (this.Const.DLC.Wildmen)
			{
				weapons.extend([
					"weapons/two_handed_flail",
					"weapons/two_handed_flanged_mace",
					"weapons/bardiche"
				]);
			}

			items.equip(this.new("scripts/items/" + weapons[this.Math.rand(0, weapons.len() - 1)]));
		}

		if (items.hasEmptySlot(this.Const.ItemSlot.Offhand))
		{
			local offhand = [
				"tools/throwing_net",
				"shields/oriental/metal_round_shield"
			];
			items.equip(this.new("scripts/items/" + offhand[this.Math.rand(0, offhand.len() - 1)]));
		}

		local a = this.Const.World.Common.pickArmor([
			[1, "oriental/gladiator_harness"]
		]);

		r = this.Math.rand(1, 2);

		if (r == 1)
		{
			a.setUpgrade(this.new("scripts/items/legend_armor/armor_upgrades/legend_light_gladiator_upgrade"));
		}
		else if (r == 2)
		{
			a.setUpgrade(this.new("scripts/items/legend_armor/armor_upgrades/legend_heavy_gladiator_upgrade"));
		}
		items.equip(a);

		items.equip(this.Const.World.Common.pickHelmet([
			[1, "oriental/gladiator_helmet", this.Math.rand(13, 15)],
			[1, ""]
		]));

	}

});

