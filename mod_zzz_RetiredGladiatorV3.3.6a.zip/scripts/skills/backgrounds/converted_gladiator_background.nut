this.converted_gladiator_background <- this.inherit("scripts/skills/backgrounds/character_background", {
	m = {},
	function create()
	{
		this.character_background.create();
		this.m.ID = "background.converted_gladiator";
		this.m.Name = "Converted Gladiator";
		this.m.Icon = "ui/backgrounds/background_61.png";
		this.m.HiringCost = 200;
		this.m.DailyCost = 28; //default gladiator is ~38
		this.m.Excluded = [
			"trait.superstitious",
			"trait.fear_beasts",
			"trait.fear_greenskins",
			"trait.fear_undead",
			"trait.fear_nobles",
			"trait.weasel",
			"trait.night_blind",
			"trait.legend_fear_dark",
			"trait.sureshot",
			"trait.ailing",
			"trait.asthmatic",
			"trait.clubfooted",
			"trait.hesitant",
			"trait.tiny",
			"trait.fragile",
			"trait.clumsy",
			"trait.fainthearted",
			"trait.craven",
			"trait.bleeder",
			"trait.dastard",
			"trait.insecure",
			"trait.gluttonous",
			"trait.fat",
			"trait.drunkard",
			"trait.greedy",
			"trait.slack"
		];

		this.m.Modifiers.Terrain = [
				0.0, // ?
				0.0, //ocean
				0.0, //plains
				0.0, //swamp
				0.0, //hills
				0.0, //forest
				0.0, //forest
				0.0, //forest_leaves
				0.0, //autumn_forest
				0.0, //mountains
				0.0, // ?
				0.0, //farmland
				0.0, // snow
				0.0, // badlands
				0.0, //highlands
				0.05, //steppes
				0.0, //ocean
				0.1, //desert
				0.1 //oasis
			];

		this.m.PerkTreeDynamic = {
			Weapon = [
				this.Const.Perks.PolearmTree,
				this.Const.Perks.SwordTree,
				this.Const.Perks.ThrowingTree,
				this.Const.Perks.CleaverTree,
				this.Const.Perks.FlailTree,
				this.Const.Perks.SpearTree,
				this.Const.Perks.DaggerTree,
				this.Const.Perks.ShieldTree,
				this.Const.Perks.FistsTree
			],
			Defense = [
				this.Const.Perks.HeavyArmorTree,
				this.Const.Perks.MediumArmorTree,
				this.Const.Perks.LightArmorTree
			],
			Traits = [
				this.Const.Perks.ViciousTree,
				this.Const.Perks.IndestructibleTree,
				this.Const.Perks.AgileTree,
				this.Const.Perks.LargeTree,
				this.Const.Perks.FitTree
			],
			Enemy = [
				this.Const.Perks.CivilizationTree
			],
			Class = [
				this.Const.Perks.BeastClassTree
			],
			Magic = [
				this.Const.Perks.RetiredGladiatorTreeLight
			]
		}
	}

	function onBuildDescription()
	{
		return "{%name% has fought long and hard during your employ, where you found them a slave with little to their name. | %name% has stood beside you and grew into an expereinced fighter where others would\'ve turned tail.| %name% showed a lot of promise when you first met them.} {Forged in the heat of the south and sharpened in battle, %name% is a fine addition to any fighting force. | Who %name% once was is no longer relevant — what matters now is that their life of servitude is long behind them and are free to do as they wish. | %name% has honed both their body and mind to become not just a fighter, but a thinker also. When not fighting, they think about how to best protect themselves and others. When not thinking, they do not take, only preserve.}";
	}

	// function onSetAppearance()
	// {
	// 	local actor = this.getContainer().getActor();
	// 	local tattoo_body = actor.getSprite("tattoo_body");
	// 	local tattoo_head = actor.getSprite("tattoo_head");

	// 	if (this.Math.rand(1, 100) <= 25)
	// 	{
	// 		local body = actor.getSprite("body");
	// 		tattoo_body.setBrush("scar_02_" + body.getBrush().Name);
	// 		tattoo_body.Visible = true;
	// 	}

	// 	if (this.Math.rand(1, 100) <= 30)
	// 	{
	// 		tattoo_head.setBrush("scar_02_head");
	// 		tattoo_head.Visible = true;
	// 	}
	// }

	// function updateAppearance()
	// {
	// 	local actor = this.getContainer().getActor();
	// 	local tattoo_body = actor.getSprite("tattoo_body");

	// 	if (tattoo_body.HasBrush)
	// 	{
	// 		local body = actor.getSprite("body");
	// 		tattoo_body.setBrush("scar_02_" + body.getBrush().Name);
	// 	}
	// }

});

