this.beastslayer_gladiator_background <- this.inherit("scripts/skills/backgrounds/character_background", {
	m = {},
	function create()
	{
		this.character_background.create();
		this.m.ID = "background.gladiator";
		this.m.Name = "Wyrm Hunter";
		this.m.Icon = "ui/backgrounds/background_nosteponsnek.png";
		this.m.BackgroundDescription = "Forced to fight impossible odds as a child, %name% shocked everyone by slaying hyenas and lindwurms with equal ease. Many flocked to see the giant clad in muscle and scars, making %name% wealthy enough to buy their freedom and travel north. When met with disdain from the northern townships they wandered into the wilderness to find more things to kill — this is when, against all odds, you met and forged a friendship that feels a lifetime in the making.";
		this.m.GoodEnding = "With the gilded path of the gladiator at an end, %name% returned home to the arena — not to fight, but as a storyteller for the children and commonfolk who could not afford to see the wonders of the beasts within those walls. Their tales shocked and moved those whose lives barely left the confines of the city walls. Little did %name% know that after their death, the stories they told left a greater mark than the giant who once slew them.";
		this.m.BadEnding = "With their time in the company over and the errant gladiator gone, %name% returned to a life they had always known — a life of solidarity with nature and isolation from the outside world. What became of %name% is unknown, but some still speak of the giant of the woods...a vengeful spirit that stalks the land looking for an old friend.";
		this.m.HiringCost = 10000000000;
		this.m.DailyCost = 40;
		this.m.Excluded = [
			"trait.superstitious",
			"trait.fear_beasts",
			"trait.fear_greenskins",
			"trait.fear_nobles",
			"trait.weasel",
			"trait.gluttonous",
			"trait.greedy",
			"trait.disloyal",
			"trait.survivor",
			"trait.night_blind",
			"trait.legend_fear_dark",
			"trait.ailing",
			"trait.asthmatic",
			"trait.clubfooted",
			"trait.hesitant",
			"trait.tiny",
			"trait.fragile",
			"trait.clumsy",
			"trait.fainthearted",
			"trait.craven",
			"trait.bleeder",
			"trait.dastard",
			"trait.insecure",
			"trait.light"
		];
		this.m.Titles = [
			"Pup-Clubber",
			"the Strongarm",
			"the Tracker",
			"Worm Killer",
			"Snake-Strangler"
		];
			this.m.ExcludedTalents = [
			this.Const.Attributes.RangedDefense
		];
		if (this.Math.rand(1, 2))
		{
			this.m.Bodies = this.Const.Bodies.Gladiator;
			this.m.Faces = this.Const.Faces.SouthernMale;
			this.m.Hairs = this.Const.Hair.SouthernMale;
			this.m.HairColors = this.Const.HairColors.Southern;
			this.m.Beards = this.Const.Beards.Southern;
			this.m.BeardChance = 60;
			this.m.Ethnicity = 1;
		}
		else
		{
			this.m.Bodies = this.Const.Bodies.AfricanGladiator;
			this.m.Faces = this.Const.Faces.AfricanMale;
			this.m.Hairs = this.Const.Hair.SouthernMale;
			this.m.HairColors = this.Const.HairColors.African;
			this.m.Beards = this.Const.Beards.Southern;
			this.m.BeardChance = 60;
			this.m.Ethnicity = 2;
		}

		this.m.Names = this.Const.Strings.SouthernNames;
		this.m.LastNames = this.Const.Strings.SouthernNamesLast;
		this.m.Level = 4
		this.m.BackgroundType = this.Const.BackgroundType.Combat;
		this.m.Modifiers.Gathering = this.Const.LegendMod.ResourceModifiers.Gather[2];
		this.m.Modifiers.Stash = this.Const.LegendMod.ResourceModifiers.Stash[1];
		this.m.Modifiers.Ammo = this.Const.LegendMod.ResourceModifiers.Ammo[2];
		this.m.Modifiers.Hunting = this.Const.LegendMod.ResourceModifiers.Hunting[2];
		this.m.Modifiers.Training = this.Const.LegendMod.ResourceModifiers.Training[2];
		this.m.Modifiers.Terrain = [
			0.0, // ?
			0.0, //ocean
			0.0, //plains
			0.0, //swamp
			0.0, //hills
			0.0, //forest
			0.0, //forest
			0.0, //forest_leaves
			0.0, //autumn_forest
			0.01, //mountains
			0.0, // ?
			0.0, //farmland
			0.0, // snow
			0.05, // badlands
			0.0, //highlands
			0.05, //steppes
			0.0, //ocean
			0.3, //desert
			0.3 //oasis
		];
		this.m.PerkTreeDynamic = {
			Weapon = [
				this.Const.Perks.PolearmTree,
				this.Const.Perks.SwordTree,
				this.Const.Perks.ShieldTree,
				this.Const.Perks.DaggerTree,
				this.Const.Perks.CleaverTree,
				this.Const.Perks.FistsTree,
				this.Const.Perks.ThrowingTree
			],
			Defense = [
				this.Const.Perks.MediumArmorTree,
				this.Const.Perks.HeavyArmorTree
			],
			Traits = [
				this.Const.Perks.ViciousTree,
				this.Const.Perks.IndestructibleTree,
				this.Const.Perks.AgileTree,
				this.Const.Perks.LargeTree,
				this.Const.Perks.FitTree
			],
			Enemy = [
				this.Const.Perks.BeastTree
			],
			Class = [
				this.Const.Perks.BeastClassTree
			],
			Profession = [],
			Magic = [
				this.Const.Perks.RangerHuntMagicTree
			]
		}
	}
		
	function setGender( _gender = -1 )
	{
		if (_gender == -1) _gender = ::Legends.Mod.ModSettings.getSetting("GenderEquality").getValue() == "Disabled" ? 0 : ::Math.rand(0, 1);

		if (_gender != 1) return;
		if (this.m.Ethnicity == 1)
		{
			this.m.Faces = this.Const.Faces.SouthernFemale;
			this.m.Hairs = this.Const.Hair.SouthernFemale;
			this.m.HairColors = this.Const.HairColors.Young;
			this.m.Bodies = this.Const.Bodies.SouthernFemaleMuscular;
		}
		else
		{
			this.m.Faces = this.Const.Faces.AfricanFemale;
			this.m.Hairs = this.Const.Hair.SouthernFemale;
			this.m.HairColors = this.Const.HairColors.African;
			this.m.Bodies = this.Const.Bodies.AfricanFemaleMuscular;
		}
		
		this.m.Beards = null;
		this.m.BeardChance = 0;
		this.addBackgroundType(this.Const.BackgroundType.Female);
	}

	function onBuildDescription()
	{
		if(this.isBackgroundType(this.Const.BackgroundType.Female))
		{
			return "{Forced to fight impossible odds as a child, %name% shocked everyone by slaying hyenas and lindwurms with equal ease. Many flocked to see the giant clad in muscle and scars, making %name% wealthy enough to buy their freedom and travel north. When met with disdain from the northern townships they wandered into the wilderness to find more things to kill — this is when, against all odds, you met and forged a friendship that feels a lifetime in the making.}";
		}
	}

	function onSetAppearance()
	{
		local actor = this.getContainer().getActor();
		local tattoo_body = actor.getSprite("tattoo_body");
		local tattoo_head = actor.getSprite("tattoo_head");

		if (this.Math.rand(1, 100) <= 25)
		{
			local body = actor.getSprite("body");
			tattoo_body.setBrush("scar_02_" + body.getBrush().Name);
			tattoo_body.Visible = true;
		}

		if (this.Math.rand(1, 100) <= 30)
		{
			tattoo_head.setBrush("scar_02_head");
			tattoo_head.Visible = true;
		}
	}

	function updateAppearance()
	{
		local actor = this.getContainer().getActor();
		local tattoo_body = actor.getSprite("tattoo_body");

		if (tattoo_body.HasBrush)
		{
			local body = actor.getSprite("body");
			tattoo_body.setBrush("scar_02_" + body.getBrush().Name);
		}
	}

	function onChangeAttributes()
	{
		local c = {
			Hitpoints = [
				18,
				23
			],
			Bravery = [
				18,
				23
			],
			Stamina = [
				14,
				20
			],
			MeleeSkill = [
				4,
				8
			],
			RangedSkill = [
				11,
				16
			],
			MeleeDefense = [
				4,
				7
			],
			RangedDefense = [
				-8,
				-8
			],
			Initiative = [
				10,
				25
			]
		};
		return c;
	}

	function onAdded()
	{
		this.character_background.onAdded();
		local actor = this.getContainer().getActor();
		this.m.Container.add(this.new("scripts/skills/traits/huge_trait"));
		this.m.Container.add(this.new("scripts/skills/perks/perk_legend_throw_sand"));
	}

	function onAddEquipment()
	{
		local talents = this.getContainer().getActor().getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.RangedSkill] = 2;
		talents[this.Const.Attributes.Hitpoints] = 1;
		this.getContainer().getActor().fillTalentValues(2, true);
		local items = this.getContainer().getActor().getItems();
		local r;

		if (items.hasEmptySlot(this.Const.ItemSlot.Mainhand))
		{
			local weapons = [
				"weapons/oriental/saif",
				"weapons/oriental/nomad_mace",
				"weapons/fighting_axe",
				"weapons/fighting_spear"
			];

			if (this.Const.DLC.Wildmen)
			{
				weapons.extend([
					"weapons/two_handed_flanged_mace",
					"weapons/bardiche"
				]);
			}

			items.equip(this.new("scripts/items/" + weapons[this.Math.rand(0, weapons.len() - 1)]));
		}

		if (items.hasEmptySlot(this.Const.ItemSlot.Offhand))
		{
			local offhand = [
				"tools/throwing_net"
			];
			items.equip(this.new("scripts/items/" + offhand[this.Math.rand(0, offhand.len() - 1)]));
		}

		local a = this.Const.World.Common.pickArmor([
			[1, "oriental/gladiator_harness"]
		]);

		r = this.Math.rand(1, 2);

		if (r == 1)
		{
			a.setUpgrade(this.new("scripts/items/legend_armor/armor_upgrades/legend_light_gladiator_upgrade"));
		}
		else if (r == 2)
		{
			a.setUpgrade(this.new("scripts/items/legend_armor/armor_upgrades/legend_heavy_gladiator_upgrade"));
		}
		items.equip(a);

		items.equip(this.Const.World.Common.pickHelmet([
			[1, "oriental/gladiator_helmet", this.Math.rand(13, 15)],
			[1, ""]
		]));

	}

});

