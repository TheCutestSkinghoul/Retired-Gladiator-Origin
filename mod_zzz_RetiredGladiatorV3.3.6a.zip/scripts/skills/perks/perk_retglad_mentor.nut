this.perk_retglad_mentor <- this.inherit("scripts/skills/skill", {
	m = {},
	
	function create()
	{
		this.m.ID = "perk.retglad_mentor";
		this.m.Name = this.Const.Strings.PerkName.RetGladMentor;
		this.m.Description = this.Const.Strings.PerkDescription.RetGladMentor;
		this.m.Icon = "ui/perks/perk_retired.png";
		// this.m.IconDisabled = "ui/perks/perk_retired_bw.png";
		this.m.Type = this.Const.SkillType.Perk;
		this.m.Order = this.Const.SkillOrder.Perk;
		this.m.IsActive = false;
		this.m.IsStacking = false;
		this.m.IsHidden = false;
	}

});
