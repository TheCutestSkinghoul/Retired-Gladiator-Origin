this.perk_retglad_stoic <- this.inherit("scripts/skills/skill", {
	m = {},
	function create()
	{
		this.m.ID = "perk.retglad_stoic";
		this.m.Name = this.Const.Strings.PerkName.RetGladStoic;
		this.m.Description = this.Const.Strings.PerkDescription.RetGladStoic;
		this.m.Icon = "ui/perks/perk_stoic.png";
		// this.m.IconDisabled = "ui/perks/perk_stoic_bw.png";
		this.m.Type = this.Const.SkillType.Perk;
		this.m.Order = this.Const.SkillOrder.Perk;
		this.m.IsActive = false;
		this.m.IsStacking = false;
		this.m.IsHidden = false;
	}

	function onAdded()
	{
		if (!this.m.Container.hasSkill("actives.retglad_stoic"))
		{
			this.m.Container.add(this.new("scripts/skills/actives/retglad_stoic"));
		}
	}

	function onRemoved()
	{
		this.m.Container.removeByID("actives.retglad_stoic");
	}

});

