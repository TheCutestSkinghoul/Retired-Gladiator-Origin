this.perk_retglad_rapid_advance <- this.inherit("scripts/skills/skill", {
	m = {},
	function create()
	{
		this.m.ID = "perk.retglad_rapid_advance";
		this.m.Name = this.Const.Strings.PerkName.RetGladRapidAdvance;
		this.m.Description = this.Const.Strings.PerkDescription.RetGladRapidAdvance;
		this.m.Icon = "ui/perks/perk_rapid_advance.png";
		// this.m.IconDisabled = "ui/perks/perk_rapid_advance_bw.png";
		this.m.Type = this.Const.SkillType.Perk | this.Const.SkillType.StatusEffect;
		this.m.Order = this.Const.SkillOrder.Perk;
		this.m.IsActive = false;
		this.m.IsStacking = false;
		this.m.IsHidden = false;
	}

	function getBonus()
	{
		if (this.getContainer() == null)
		{
			return 0;
		}

		local actor = this.getContainer().getActor();

		if (actor == null)
		{
			return 0;
		}

		local initiative = actor.getCurrentProperties().getInitiative();
		local fraction = initiative / 65.0;
		local normal = this.Math.floor(fraction * 100);
		local bonus = normal * 0.01;

		return bonus;
	}

	function getTooltip()
	{
		local bonus = this.getBonus();
		if (bonus > 1)
		{
		bonus = this.Math.pow(bonus, 0.5);
		}
		local reduction = this.Math.round((1 - 1 / bonus)*100);
		local tooltip = this.skill.getTooltip();

		if (bonus > 1)
		{
			tooltip.push({
				id = 6,
				type = "text",
				icon = "ui/icons/fatigue.png",
				text = "All your fatigue costs are reduced by [color=" + this.Const.UI.Color.PositiveValue + "]" + reduction + "%[/color]."
			});
		}
		else
		{
			tooltip.push({
				id = 6,
				type = "text",
				icon = "ui/tooltips/warning.png",
				text = "This character does not have enough initiative to benefit from Rapid Advance!"
			});
		}

		return tooltip;
	}

	function onUpdate( _properties )
	{
		local bonus = this.getBonus();
		if (bonus > 1)
		{
		bonus = this.Math.pow(bonus, 0.5);
		_properties.FatigueEffectMult *= 1.0 / bonus;
		}
	}

});

