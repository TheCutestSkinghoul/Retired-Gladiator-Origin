this.perk_retglad_path <- this.inherit("scripts/skills/skill", {
	m = {},
	function create()
	{
		this.m.ID = "perk.retglad_path";
		this.m.Name = this.Const.Strings.PerkName.RetGladPath;
		this.m.Description = this.Const.Strings.PerkDescription.RetGladPath;
		this.m.Icon = "ui/perks/perk_mentor.png";
		this.m.Type = this.Const.SkillType.Perk | this.Const.SkillType.StatusEffect;
		this.m.Order = this.Const.SkillOrder.Perk;
		this.m.IsActive = false;
		this.m.IsStacking = false;
		this.m.IsHidden = false;
	}

	function onUpdate( _properties ) //backend
	{

		local item = this.getContainer().getActor().getMainhandItem(); //southern weapons only (no shields, ranged or offhands)
		if (item != null)
		{	//Normal rules
			if (item.getID() == "weapon.firelance" || item.getID() == "weapon.heavy_southern_mace" || item.getID() == "weapon.battle_whip" || item.getID() == "weapon.light_southern_mace" || item.getID() == "weapon.nomad_mace" || item.getID() == "weapon.polemace" || item.getID() == "weapon.qatal_dagger" || item.getID() == "weapon.saif" || item.getID() == "weapon.swordlance" || item.getID() == "weapon.two_handed_saif" || item.getID() == "weapon.two_handed_scimitar" || item.getID() == "weapon.legend_katar" || item.getID() == "weapon.scimitar" || item.getID() == "weapon.shamshir" || item.getID() == "weapon.crypt_cleaver" || item.getID() == "weapon.khopesh" || item.getID() == "weapon.legend_great_khopesh" || item.getID() == "weapon.legend_khopesh" || item.getID() == "weapon.legend_kopis" || item.getID() == "weapon.Warscythe" || item.getID() == "weapon.spetum")
			{
				_properties.MeleeDamageMult *= 1.05;
				_properties.DamageArmorMult *= 1.1; //effectiveness vs armour
				_properties.XPGainMult *= 1.1; //10%
			}
			//Named rules
			else if (item.getID() == "weapon.named_battle_whip" || item.getID() == "weapon.named_mace" || item.getID() == "weapon.named_polemace" || item.getID() == "weapon.named_qatal_dagger" || item.getID() == "weapon.named_royal_lance" || item.getID() == "weapon.named_shamshir" || item.getID() == "weapon.named_swordlance" || item.getID() == "weapon.named_two_handed_scimitar" || item.getID() == "weapon.legend_mage_swordstaff" || item.getID() == "weapon.lightbringer_sword" || item.getID() == "weapon.obsidian_dagger" || item.getID() == "weapon.named_crypt_cleaver" || item.getID() == "weapon.named_khopesh" || item.getID() == "weapon.named_legend_great_khopesh" || item.getID() == "weapon.named_warscythe" || item.getID() == "weapon.named_spetum")
			{
				_properties.MeleeDamageMult *= 1.1;
				_properties.DamageArmorMult *= 1.2; //effectiveness vs armour
				_properties.FatigueOnSkillUse -= 5;
				_properties.XPGainMult *= 1.15; //15%
			}
			//Normal rules
			else if (item.getID() == "weapon.staff_sling" || item.getID() == "weapon.composite_bow" || item.getID() == "weapon.handgonne" || item.getID() == "weapon.nomad_sling" || item.getID() == "weapon.legend_sling")
			{
				_properties.MeleeDamageMult *= 1.05;
				_properties.DamageArmorMult *= 1.1; //effectiveness vs armour
				_properties.XPGainMult *= 1.1; //10%
			}
			//Named rules 
			else if (item.getID() == "weapon.named_handgonne" || item.getID() == "weapon.legend_named_nomad_sling" || item.getID() == "weapon.legend_named_northern_sling")
			{
				_properties.MeleeDamageMult *= 1.1;
				_properties.DamageArmorMult *= 1.2; //effectiveness vs armour
				_properties.FatigueOnSkillUse -= 5;
				_properties.XPGainMult *= 1.15; //15%
			}
			//Everything else
			else
			{
				return
			}
		}
	}

	function getDescription()
	{
		return "[color=" + this.Const.UI.Color.PositiveValue + "]Valid \'Southern Melee Weapons\' include:[/color] Firelance, Heavy or Light Southern Mace, Nomad Mace, Whip, Polemace, Qatal Dagger, Saif, Swordlance, Two-Handed Saif, Two-Handed scimitar, Katar, Scimitar, Spetum and Shamshir.\n [color=" + this.Const.UI.Color.PositiveValue + "]Valid \'Named\' items include:[/color] Whip, One-Handed Mace (all types), Polemace, Qatal Dagger, Shamshir, Swordlance, Spetum and Two-Handed Scimitar.\n\n Extends to the Crypt Cleaver, Khopesh, Great Khopesh, Brass Cleaver, Kopis and Warscythe.\n\n Also includes the Obsidian Dagger, Bladed Magestaff, Royal Lance and Reproach of the Old Gods.\n\n[color=" + this.Const.UI.Color.PositiveValue + "]Valid \'Southern Ranged Weapons\' include:[/color] All slings, Composite Bow and Handgonne.\n [color=" + this.Const.UI.Color.PositiveValue + "]Valid \'Southern Named Weapons\' include:[/color] Hangonne, Nomad Sling and Northern Sling.";
	}

	function getTooltip() //frontend
	{
		local tooltip = this.skill.getTooltip();
		local item = this.getContainer().getActor().getItems().getItemAtSlot(this.Const.ItemSlot.Mainhand);
		
		//no need to continue if no item
		if (item == null) return tooltip;

		local normalMeleeWeapons = [
			"weapon.firelance",
			"weapon.heavy_southern_mace",
			"weapon.battle_whip",
			"weapon.light_southern_mace",
			"weapon.nomad_mace",
			"weapon.polemace",
			"weapon.qatal_dagger",
			"weapon.saif",
			"weapon.swordlance",
			"weapon.two_handed_saif",
			"weapon.two_handed_scimitar",
			"weapon.legend_katar",
			"weapon.scimitar",
			"weapon.shamshir",
			"weapon.crypt_cleaver",
			"weapon.khopesh",
			"weapon.legend_great_khopesh",
			"weapon.legend_khopesh",
			"weapon.legend_kopis",
			"weapon.warscythe",
			"weapon.spetum",
		];
		local namedMeleeWeapons = [
			"weapon.named_battle_whip",
			"weapon.named_mace",
			"weapon.named_polemace",
			"weapon.named_qatal_dagger",
			"weapon.named_royal_lance",
			"weapon.named_shamshir",
			"weapon.named_swordlance",
			"weapon.named_two_handed_scimitar",
			"weapon.legend_mage_swordstaff",
			"weapon.lightbringer_sword",
			"weapon.obsidian_dagger",
			"weapon.named_crypt_cleaver",
			"weapon.named_khopesh",
			"weapon.named_legend_great_khopesh",
			"weapon.named_warscythe",
			"weapon.named_spetum",
		];
		local normalRangedWeapons = [
			"weapon.staff_sling", 
			"weapon.composite_bow", 
			"weapon.handgonne", 
			"weapon.nomad_sling",
			"weapon.legend_sling",
		];
		local namedRangedWeapons = [
			"weapon.named_handgonne",
			"weapon.legend_named_nomad_sling",
			"weapon.legend_named_northern_sling"

		];

		if (normalMeleeWeapons.find(item.getID()) != null)
		{
			tooltip.push({
				id = 6,
				type = "text",
				icon = "ui/icons/mentor_normal.png",
				text = "Gaining [color=" + this.Const.UI.Color.PositiveValue + "]+5% damage, 10% effectiveness against armour and 10% more experience earned from holding a southern melee weapon[/color]."
			});
		}
		else if (namedMeleeWeapons.find(item.getID()) != null)
		{
			tooltip.push({
				id = 6,
				type = "text",
				icon = "ui/icons/mentor_special.png",
				text = "Gaining [color=" + this.Const.UI.Color.PositiveValue + "]+10% damage, 20% effectiveness against armour, -5 fatigue used when using this weapon and 15% more experience earned from holding a named or unique southern melee weapon[/color]."
			});
		}
		else if (normalRangedWeapons.find(item.getID()) != null)
		{
			tooltip.push({
				id = 6,
				type = "text",
				icon = "ui/icons/mentor_normal.png",
				text = "Gaining [color=" + this.Const.UI.Color.PositiveValue + "]+5% damage, 10% effectiveness against armour and 10% more experience earned from holding a southern ranged weapon[/color]."
			});
		}
		else if (namedRangedWeapons.find(item.getID()) != null)
		{
			tooltip.push({
				id = 6,
				type = "text",
				icon = "ui/icons/mentor_special.png",
				text = "Gaining [color=" + this.Const.UI.Color.PositiveValue + "]+10% damage, 20% effectiveness against armour, -5 fatigue used when using this weapon and 15% more experience earned from holding a named southern ranged weapon[/color]."
			});
		}

		else
		{
			tooltip.push({
				id = 6,
				type = "text",
				icon = "ui/tooltips/warning.png",
				text = "[color=" + this.Const.UI.Color.NegativeValue + "]This character is not using a valid southern weapon, and is not gaining any bonuses from the \'The Gilded Path\' perk![/color]."
			});
		}

		return tooltip;
	}

});
