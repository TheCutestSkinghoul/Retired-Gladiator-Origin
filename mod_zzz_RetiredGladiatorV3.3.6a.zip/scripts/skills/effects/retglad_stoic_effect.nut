this.retglad_stoic_effect <- this.inherit("scripts/skills/skill", {
	m = {},
	function create()
	{
		this.m.ID = "effects.retglad_stoic";
		this.m.Name = "Stoicism";
		this.m.Icon = "ui/perks/perk_stoic_active.png";
		this.m.IconMini = "perk_30_mini"; //TO DO
		this.m.Overlay = "perk_30"; //TO DO
		this.m.Type = this.Const.SkillType.StatusEffect;
		this.m.IsActive = false;
		this.m.IsRemovedAfterBattle = true;
	}

	function getDescription()
	{
		return "They can only hurt you if you let them.";
	}

	function getTooltip()
	{
		return [
			{
				id = 1,
				type = "title",
				text = this.getName()
			},
			{
				id = 2,
				type = "description",
				text = this.getDescription()
			},
			{
				id = 6,
				type = "text",
				icon = "ui/icons/special.png",
				text = "Receives only [color=" + this.Const.UI.Color.PositiveValue + "]40%[/color] of any damage"
			},
			{
				id = 6,
				type = "text",
				icon = "ui/icons/special.png",
				text = "[color=" + this.Const.UI.Color.PositiveValue + "]Is not affected by injuries[/color]"
			},
			{
				id = 6,
				type = "text",
				icon = "ui/icons/special.png",
				text = "[color=" + this.Const.UI.Color.PositiveValue + "]Reduces all negative effect durations by 1 turn[/color]"
			}
		];
	}

	function onUpdate( _properties )
	{
		_properties.IsAffectedByInjuries = false;

		_properties.DamageReceivedTotalMult *= 0.6;

		_properties.NegativeStatusEffectDuration += -5;
	}

	function onTurnStart()
	{
		this.removeSelf();
	}

});

