local modID = "mod_LuftRetiredGladiatorOrigin";

::mods_registerMod(modID, 3.3, "Luft\'s Retired Gladiator Origin");
::mods_queue(modID, "mod_legends, mod_msu", function() {
	// new perk names
	::Const.Strings.PerkName.RetGladPath <- "The Gilded Path"; //grants bonuses based on if the brother is holding a 'southern' weapon or not.
	::Const.Strings.PerkName.RetGladPreciseStrikes <- "Precise Strikes"; //netted, rooted or distracted targets have a chance to 'cripple' when hit.
	::Const.Strings.PerkName.RetGladRapidAdvance <- "Rapid Advance"; //all fatigue costs are reduced for every point over 65.
	::Const.Strings.PerkName.RetGladStoic <- "Stoic"; //When activated, ignore all current injury effects you have accumulated and reduce damage you take by 40% for 3 turns. Negitive effects last 1 turn less.
	::Const.Strings.PerkName.RetGladMentor <- "Mentor"; //Unlocks new events.

	// new perk descriptions
	::Const.Strings.PerkDescription.RetGladPath <- "Many mistakes are often made as a result of ignorance, the fighters of today have been tarnished by the crudeness of northern weapons — all corrections made must be educational.\n\n When using a southern melee or ranged weapon, gain [color=" + ::Const.UI.Color.PositiveValue + "]+5%[/color] damage, [color=" + ::Const.UI.Color.PositiveValue + "]+10%[/color] more effectiveness against armour and [color=" + ::Const.UI.Color.PositiveValue + "]+10%[/color] more experience gained. Using a named or unique weapon of a southern origin increases these effects. [color=" + ::Const.UI.Color.NegativeValue + "]Does not work for shields or offhand items[/color]";

	::Const.Strings.PerkDescription.RetGladPreciseStrikes <- "You should never expect bad people to exempt you from their destructive ways, every advantage you have must be taken.\n\n When attacking an enemy in nets, webs, roots or distracted by thrown dirt you will add a stack of [color=" + ::Const.UI.Color.PositiveValue + "]\'crippled\'[/color], which reduces the damage your target deals and takes by 5% per stack";

	::Const.Strings.PerkDescription.RetGladRapidAdvance <- "At all times it is important to maintain self control. Life is short, after all.\n\n All fatigue costs are reduced for every [color=" + ::Const.UI.Color.PositiveValue + "]current[/color] initiative point over [color=" + ::Const.UI.Color.PositiveValue + "]65[/color], the higher your initiative the more you benefit. If you are below this value, this perk has no effect";

	::Const.Strings.PerkDescription.RetGladStoic <- "Others around you can only harm you if you let them.\n\n When activated, gain immunity to fresh injury effects, [color=" + ::Const.UI.Color.PositiveValue + "]+60%[/color] damage resistance and reduce the duration of all negative effects on you by 1 turn. This ability lasts 1 turn when activated";

	::Const.Strings.PerkDescription.RetGladMentor <- "You have considered yourself dead — you now aim to use what remains of your life properly.\n\n Taking this perk will give access to dilemmas to convert indebted in your party to gladiators and improve gladiators.";


	local perkDefObjects = [];
	::Legends.Perk.RetGladPath <- null;
	perkDefObjects.push({
		ID = "perk.retglad_path",
		Script = "scripts/skills/perks/perk_retglad_path",
		Name = ::Const.Strings.PerkName.RetGladPath,
		Tooltip = ::Const.Strings.PerkDescription.RetGladPath,
		Icon = "ui/perks/perk_mentor.png",
		IconDisabled = "ui/perks/perk_mentor_bw.png",
		Const = "RetGladPath"
	});

	::Legends.Perk.RetGladPreciseStrikes <- null;
	perkDefObjects.push({
		ID = "perk.retglad_precise_strikes",
		Script = "scripts/skills/perks/perk_retglad_precise_strikes",
		Name = ::Const.Strings.PerkName.RetGladPreciseStrikes,
		Tooltip = ::Const.Strings.PerkDescription.RetGladPreciseStrikes,
		Icon = "ui/perks/perk_precise_strikes.png",
		IconDisabled = "ui/perks/perk_precise_strikes_bw.png",
		Const = "RetGladPreciseStrikes"
	});

	::Legends.Perk.RetGladRapidAdvance <- null;
	perkDefObjects.push({
		ID = "perk.retglad_rapid_advance",
		Script = "scripts/skills/perks/perk_retglad_rapid_advance",
		Name = ::Const.Strings.PerkName.RetGladRapidAdvance,
		Tooltip = ::Const.Strings.PerkDescription.RetGladRapidAdvance,
		Icon = "ui/perks/perk_rapid_advance.png",
		IconDisabled = "ui/perks/perk_rapid_advance_bw.png",
		Const = "RetGladRapidAdvance"
	});

	::Legends.Perk.RetGladStoic <- null;
	perkDefObjects.push({
		ID = "perk.retglad_stoic",
		Script = "scripts/skills/perks/perk_retglad_stoic",
		Name = ::Const.Strings.PerkName.RetGladStoic,
		Tooltip = ::Const.Strings.PerkDescription.RetGladStoic,
		Icon = "ui/perks/perk_stoic.png",
		IconDisabled = "ui/perks/perk_stoic_bw.png",
		Const = "RetGladStoic"
	});

	::Legends.Perk.RetGladMentor <- null;
	perkDefObjects.push({
		ID = "perk.retglad_mentor",
		Script = "scripts/skills/perks/perk_retglad_mentor",
		Name = ::Const.Strings.PerkName.RetGladMentor,
		Tooltip = ::Const.Strings.PerkDescription.RetGladMentor,
		Icon = "ui/perks/perk_retired.png",
		IconDisabled = "ui/perks/perk_retired_bw.png",
		Const = "RetGladMentor"
	});

	::Const.Perks.addPerkDefObjects(perkDefObjects);

	if (!("Perks" in ::Const))
	{
		::Const.Perks <- {};
	}

	::Const.Perks.RetiredGladiatorTree <- {
		ID = "RetiredGladiatorTree",
		Name = "Retired Gladiator"
		Descriptions = [
			"Retired Gladiator"
		],
		Icon = "ui/perks/perk_retglad_mentor.png",
		Tree = [
			[::Legends.Perk.RetGladPath], //1
			[], //2
			[::Legends.Perk.RetGladPreciseStrikes], //3
			[::Legends.Perk.RetGladRapidAdvance], //4
			[::Legends.Perk.RetGladStoic], //5
			[], //6
			[::Legends.Perk.RetGladMentor] //7
		]
	};

	::Const.Perks.RetiredGladiatorTreeLight <- {
		ID = "RetiredGladiatorTreeLight",
		Name = "Retired Gladiator Light"
		Descriptions = [
			"Retired Gladiator Light"
		],
		Icon = "ui/perks/perk_retglad_path.png",
		Tree = [
			[::Legends.Perk.RetGladPath], //1 They should have they already but w/e
			[], //2
			[::Legends.Perk.RetGladPreciseStrikes], //3
			[::Legends.Perk.RetGladRapidAdvance], //4
			[::Legends.Perk.RetGladStoic], //5
			[], //6
			[] //7
		]
	};
});