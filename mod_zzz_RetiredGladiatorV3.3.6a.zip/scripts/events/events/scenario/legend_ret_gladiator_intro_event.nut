this.legend_ret_gladiator_intro_event <- this.inherit("scripts/events/event", {
	m = {},
	function create()
	{
		this.m.ID = "event.legend_ret_gladiator_intro";
		this.m.IsSpecial = true;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_176.png[/img]The horn of the arena sounds once again — the cheers of the crowd signal the death of one fool in exchange for another's meager existence. Your nails dig into your chair as the fury wails inside you — it was not long ago that your purpose was to serve the crowds and fight to the death.\nThe horn screeches again as the grip on your chair tightens. Almost a decade has passed since you let your pride outweigh your survival instincts — the Vizier wanted his son to win that fight and paid you to take a fall. Yet you butchered that boy like a lamb while his mother screamed and the crowd cheered.\n\n Stripped and beaten you were left in a stifling cell to die at the Vizier\'s pleasure. Only for the Vizier to be murdered a few years later. With the guards unpaid you made your escape, finding your way out of the warrens of tunnels to a world that had changed much since you left it — some fighters still huddle together and talk of a great gladiator who slew the Vizier\'s son many years ago. \n\n Now in this crumbling room you slowly die, death has not plucked up the courage to come for you yet and with your legacy in tatters you make the decision. You steal what you can from the arena and spend what few crowns you can muster. The arena\'s horn sounds again in the distance.\n\n One last fight.\n\n Just one...",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "No time to waste.",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.logInfo("Unlocking gathering");
				this.World.Flags.set("HasLegendCampGathering", true);
				this.logInfo("Unlocking training");
				this.World.Flags.set("HasLegendCampTraining", true);
			}

		});
	}

	function onUpdateScore()
	{
		return;
	}

	function onPrepare()
	{
		this.m.Title = "Close To The Sun";
	}

	function onPrepareVariables( _vars )
	{
		_vars.push([
			"home",
			this.World.Flags.get("HomeVillage")
		]);
	}

	function onClear()
	{
	}

});

