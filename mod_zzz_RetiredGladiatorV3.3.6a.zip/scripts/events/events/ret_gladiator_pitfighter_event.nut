this.ret_gladiator_pitfighter_event <- this.inherit("scripts/events/event", {
	m = {
		Dude = null,
		Town = null
	},
	function create()
	{
		this.m.ID = "event.ret_gladiator_pitfighter"; //—
		this.m.Title = "At %townname%";
		this.m.Cooldown = 35.0 * this.World.getTime().SecondsPerDay;
		this.m.Screens.push({
			ID = "A",
			Text = "%townImage%The horn of the arena sounds again in the distance, and for a moment you feel your body spring into action before realising you are on the wrong side of the arena\'s walls. A lonely looking man, holding a figure in chains and jerking them around like a shepard would lead a goat around a market. Some bystandaers feign interest while others openly deter the man and his leashed pet.\n\n You try to avoid the man\'s path by sweving and planning your route to take a wide berth around him, however he notices you at the last second and your accidental locking of eyes gives him an invitation to cut through the crowd towards you. %SPEECH_ON%I can see by the way you walk and the equipment you hold that you are a free gladiator making their own way in the world...%SPEECH_OFF% Well, he\'s half right. %SPEECH_ON%...and for just %money% crowns you can free this gladiator, who I am willing to part with — I\'ll even throw in all of their old equipment as part of the deal!%SPEECH_OFF%",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Alright, I\'ll take them for %money% crowns.",
					function getResult( _event )
					{
						return "B";
					}

				},
				{
					Text = "Sorry friend — but it looks like you\'ll need to stay a prisoner a little longer.",
					function getResult( _event )
					{
						this.World.getTemporaryRoster().clear();
						return 0;
					}

				}
			],
			function start( _event )
			{
				// this.Characters.push(_event.m.Dude.getImagePath());
				local money = this.Math.rand(715, 965);
				// local roster = this.World.getTemporaryRoster(); ///needed?
			}

		});
		this.m.Screens.push({
			ID = "B",
			Text = "%townImage%The pit fighter shakes their shackles loose as the slavemaster unlocks them, shooting the man a brutal glare as they walk to your side.",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "More hands always help.",
					function getResult( _event )
					{
						this.World.getPlayerRoster().add(_event.m.Dude);
						this.World.getTemporaryRoster().clear();
						_event.m.Dude.onHired();
						return 0;
					}

				}
			],
			function start( _event )
			{
				local roster = this.World.getTemporaryRoster();
				_event.m.Dude = roster.create("scripts/entity/tactical/player");
				_event.m.Dude.setStartValuesEx([
					"pit_fighter_background"
				]);
				this.Characters.push(_event.m.Dude.getImagePath());
				_event.m.Dude.getSkills().add(this.new("scripts/skills/perks/perk_retglad_path"));

				local money = this.Math.rand(715, 965);
				this.World.Assets.addMoney(-money);
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "You spend [color=" + this.Const.UI.Color.NegativeEventValue + "]" + money + "[/color] Crowns"
				});
			}
		});
	}

	function onUpdateScore()
	{

		if (this.World.Assets.getOrigin().getID() != "scenario.ret_gladiator")
		{
			return;
		}

		if (this.World.Assets.getMoney() < 1300) //above 1300 crowns to trigger
		{
			return;
		}

		if (!this.World.getTime().IsDaytime)
		{
			return;
		}

		local currentTile = this.World.State.getPlayer().getTile();

		if (!this.World.Assets.getStash().hasEmptySlot())
		{
			return;
		}

		if (this.World.getPlayerRoster().getSize() >= this.World.Assets.getBrothersMax())
		{
			return;
		}

		local towns = this.World.EntityManager.getSettlements();
		local currentTile = this.World.State.getPlayer().getTile();

		foreach( t in towns )
		{
			if (t.isSouthern() && t.getTile().getDistanceTo(currentTile) <= 4 && t.isAlliedWithPlayer() && t.hasBuilding("building.arena")) //only happens near arena
			{
				this.m.Town = t;
				break;
			}
		}

		if (this.m.Town == null)
		{
			return;
		}

		local brothers = this.World.getPlayerRoster().getAll();
		local candidates = [];

		foreach( bro in brothers )
		{
        	if (bro.getLevel() < 6 && bro.getBackground().getID() == "background.retired_gladiator") //only unlocks beyond lvl 6
			{
				candidates.push(bro);
			}
		}

		// this.m.Name = this.Const.Strings.SouthernNames[this.Math.rand(0, this.Const.Strings.SouthernNames.len() - 1)];
		this.m.Score = 10;
	}

	function onPrepare()
	{
	}

	function onPrepareVariables( _vars )
	{
		_vars.push([
			"town",
			this.m.Town.getNameOnly()
		]);
		_vars.push([
			"townname",
			this.m.Town.getNameOnly()
		]);
		_vars.push([
			"money",
			this.Math.rand(715, 965)//;
		]);
	}

	function onClear()
	{
		this.m.Dude = null;
		this.m.Town = null;
	}

});

