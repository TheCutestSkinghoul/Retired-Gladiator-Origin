this.retired_gladiator_paycut_event <- this.inherit("scripts/events/event", {
	m = {
		Gladiator = null
	},
	function create()
	{
		this.m.ID = "event.retired_gladiator_paycut";
		this.m.Title = "During camp...";
		this.m.Cooldown = 35.0 * this.World.getTime().SecondsPerDay;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_15.png[/img]%gladiator% enters your tent. Filled with the bluster and bravado that they usually are known for, they interrupt your writing and seat themselves before you can speak.%SPEECH_ON%Mentor, I see you sit in this tent for hours at a time, scribbling away on your papers rather than joining us training in the light and heat as The Gilder intended...%SPEECH_OFF% You can see where this is going, but allow it to play out. %SPEECH_ON%...you may have a name for yourself, but we should not stay in the past where you belong.%SPEECH_OFF%\n\n You let %gladiator% continue to talk, and talk they surely do. You deduct some of their wages from your ledger as they continue to talk, no doubt the change in pay will show them their place a little better.\n\n If they notice at all...",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "That turned out well.",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.Characters.push(_event.m.Gladiator.getImagePath());
				_event.m.Gladiator.getBaseProperties().DailyWage -= _event.m.Gladiator.getDailyCost() / 2;
				_event.m.Gladiator.getSkills().update();
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_daily_money.png",
					text = _event.m.Gladiator.getName() + " is now paid " + _event.m.Gladiator.getDailyCost() + " crowns a day"
				});
				_event.m.Gladiator.getFlags().add("gladiator_paycut");
			}

		});
	}

	function onUpdateScore()
	{
		local brothers = this.World.getPlayerRoster().getAll();
		local candidates = [];

		foreach( bro in brothers )
		{
			if (bro.getLevel() >= 6 && bro.getBackground().getID() == "background.gladiator" && !bro.getFlags().has("gladiator_paycut") && !bro.getSkills().hasSkill("trait.old"))
			{
				candidates.push(bro);
			}
		}

		foreach( bro in this.World.getPlayerRoster().getAll() )
		{
			if (!bro.getSkills().hasSkill("perk.retglad_mentor")) // perk check
			{
				continue;
			}
		}

		if (candidates.len() > 0)
		{
			this.m.Gladiator = candidates[this.Math.rand(0, candidates.len() - 1)];
			this.m.Score = this.m.Gladiator.getLevel();
		}
	}

	function onPrepare()
	{
	}

	function onPrepareVariables( _vars )
	{
		_vars.push([
			"gladiator",
			this.m.Gladiator.getName()
		]);
	}

	function onClear()
	{
		this.m.Gladiator = null;
	}

});

