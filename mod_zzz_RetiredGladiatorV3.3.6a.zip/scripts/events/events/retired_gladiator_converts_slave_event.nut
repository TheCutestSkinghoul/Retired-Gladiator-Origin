this.retired_gladiator_converts_slave_event <- this.inherit("scripts/events/event", {
	m = {
		retiredgladiator = null,
		slave = null
	},
	function create()
	{
		this.m.ID = "event.retired_gladiator_converts_slave";
		this.m.Title = "During camp...";
		this.m.Cooldown = 28.0 * this.World.getTime().SecondsPerDay; 
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_05.png[/img]You have had your eye on %slave% for some time — they show both fighting potential and the right mindset to progress further. You can choose to train them personally as your master did with you, but doing so would mean you accept them with wage and respect in equal measure...",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "It is time.",
					function getResult( _event )
					{
						return "B"; //accept
					}

				},
				{
					Text = "They are not ready.",
					function getResult( _event )
					{
						return "D"; //Decline
					}

				}
			],
			function start( _event )
			{
				this.Characters.push(_event.m.retiredgladiator.getImagePath());
				this.Characters.push(_event.m.slave.getImagePath());
			}

		});
		this.m.Screens.push({ //accept
			ID = "B",
			Text = "[img]gfx/ui/events/event_15.png[/img]While %slave% is overjoyed at their new freedom, there is room for improvement to make them a truely formidable fighter — skills and teachings that go beyond the gladiators of today. Which area do you think they should specialise their skills in?",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "They will strengthen their resolve",
					function getResult( _event )
					{
						return "C1"; //glorious resolve
					}
				},
				{
					Text = "They will become immovable",
					function getResult( _event )
					{
						return "C2"; //glorious endurance
					}
				},
				{
					Text = "They will be untouchable",
					function getResult( _event )
					{
						return "C3"; //glorious quickness
					}
				}
			],
			function start( _event )
			{
				this.Characters.push(_event.m.slave.getImagePath());
				local bg = this.new("scripts/skills/backgrounds/converted_gladiator_background");
				bg.m.IsNew = false;
				local oldPerkTree = _event.m.slave.getBackground().m.CustomPerkTree;
				_event.m.slave.getSkills().removeByID("background.slave");
				_event.m.slave.getSkills().add(bg);
				// _event.m.slave.getBackground().m.RawDescription = "TO DO";
				_event.m.slave.getBackground().buildDescription(true);
				_event.m.slave.getBackground().rebuildPerkTree(oldPerkTree);
				_event.m.slave.resetPerks();
				_event.m.slave.improveMood(2.0, "Escaped a long life of servitude");

				if (_event.m.slave.getMoodState() >= this.Const.MoodState.Neutral)
				{
					this.List.push({
						id = 10,
						icon = this.Const.MoodStateIcon[_event.m.slave.getMoodState()],
						text = _event.m.slave.getName() + this.Const.MoodStateEvent[_event.m.slave.getMoodState()]
					});
				}

				_event.m.slave.getBaseProperties().MeleeSkill += 10;
				_event.m.slave.getBaseProperties().RangedSkill += 15;
				_event.m.slave.getBaseProperties().MeleeDefense += 7;
				_event.m.slave.getBaseProperties().RangedDefense += 8;
				_event.m.slave.getBaseProperties().Hitpoints += 15;
				_event.m.slave.getBaseProperties().Bravery += 20;
				_event.m.slave.getBaseProperties().Stamina += 12;
				_event.m.slave.getBaseProperties().Initiative += 25;
				_event.m.slave.getSkills().update();
				
				this.List.push({
					id = 16,
					icon = "ui/icons/health.png",
					text = _event.m.slave.getName() + " gains [color=" + this.Const.UI.Color.PositiveEventValue + "]+15[/color] Hitpoints"
				});				
				this.List.push({
					id = 16,
					icon = "ui/icons/bravery.png",
					text = _event.m.slave.getName() + " gains [color=" + this.Const.UI.Color.PositiveEventValue + "]+20[/color] Resolve"
				});
				this.List.push({
					id = 16,
					icon = "ui/icons/fatigue.png",
					text = _event.m.slave.getName() + " gains [color=" + this.Const.UI.Color.PositiveEventValue + "]+12[/color] Max Fatigue"
				});
				this.List.push({
					id = 16,
					icon = "ui/icons/melee_skill.png",
					text = _event.m.slave.getName() + " gains [color=" + this.Const.UI.Color.PositiveEventValue + "]+10[/color] Melee Skill"
				});
				this.List.push({
					id = 16,
					icon = "ui/icons/melee_skill.png",
					text = _event.m.slave.getName() + " gains [color=" + this.Const.UI.Color.PositiveEventValue + "]+15[/color] Ranged Skill"
				});
				this.List.push({
					id = 16,
					icon = "ui/icons/melee_defense.png",
					text = _event.m.slave.getName() + " gains [color=" + this.Const.UI.Color.PositiveEventValue + "]+7[/color] Melee Defense"
				});
				this.List.push({
					id = 16,
					icon = "ui/icons/ranged_defense.png",
					text = _event.m.slave.getName() + " gains [color=" + this.Const.UI.Color.PositiveEventValue + "]+8[/color] Ranged Defense"
				});
				this.List.push({
					id = 16,
					icon = "ui/icons/initiative.png",
					text = _event.m.slave.getName() + " gains [color=" + this.Const.UI.Color.PositiveEventValue + "]+25[/color] Initiative"
				});
				this.List.push({
					id = 16,
					icon = "ui/icons/special.png",
					text = _event.m.slave.getName() + " is now paid a wage"
				});
			}

		});
		this.m.Screens.push({ //—
			ID = "C1", //trait pick
			Text = "[img]gfx/ui/events/event_155.png[/img]%slave% has shown great promise with their bravery in battle — they stand tall and firm against any threat and will continue to do so with greater strength now!",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Gloriously Resolute!",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.Characters.push(_event.m.slave.getImagePath());
				local glorious_resolve_trait = this.new("scripts/skills/traits/glorious_resolve_trait");
				_event.m.slave.getSkills().add(glorious_resolve_trait);
				_event.m.slave.getBaseProperties().Bravery += 8;
				this.List = [
					{
						id = 13,
						icon = glorious_resolve_trait.getIcon(),
						text = _event.m.slave.getName() + " has gained glorious resolve and an additional [color=" + this.Const.UI.Color.PositiveEventValue + "]+8[/color] Resolve"
					}
				];
			}

		});
		this.m.Screens.push({
			ID = "C2", //trait pick
			Text = "[img]gfx/ui/events/event_155.png[/img]%slave% shows great perservence in the face of overwhelming odds — their body is scarred but they continue to stand tall amidst the hardiest to ever take the field!",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Gloriously Enduring!",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.Characters.push(_event.m.slave.getImagePath());
				local glorious_endurance_trait = this.new("scripts/skills/traits/glorious_endurance_trait");
				_event.m.slave.getSkills().add(glorious_endurance_trait);
				_event.m.slave.getBaseProperties().Hitpoints += 4;
				_event.m.slave.getBaseProperties().MeleeDefense += 3;
				_event.m.slave.getBaseProperties().RangedDefense += 3;
				this.List = [
					{
						id = 13,
						icon = glorious_endurance_trait.getIcon(),
						text = _event.m.slave.getName() + " has gained glorious endurance and an additional [color=" + this.Const.UI.Color.PositiveEventValue + "]+4[/color] Hitpoints, [color=" + this.Const.UI.Color.PositiveEventValue + "]+3[/color] Melee Defence and Ranged Defence"
					}
				];
			}

		});
		this.m.Screens.push({
			ID = "C3", //trait pick
			Text = "[img]gfx/ui/events/event_155.png[/img]%slave% has shown great speed and precision in every battle so far — often being the first to strike first and to strike again. They will do so again with greater speed.",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Gloriously Swift!",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.Characters.push(_event.m.slave.getImagePath());
				local glorious_quickness_trait = this.new("scripts/skills/traits/glorious_quickness_trait");
				_event.m.slave.getSkills().add(glorious_quickness_trait);
				_event.m.slave.getBaseProperties().Stamina += 10;
				_event.m.slave.getBaseProperties().Initiative += 15;
				this.List = [
					{
						id = 13,
						icon = quickness_quickness_trait.getIcon(),
						text = _event.m.slave.getName() + " has gained glorious quickness and an additional [color=" + this.Const.UI.Color.PositiveEventValue + "]+10[/color] Fatigue and [color=" + this.Const.UI.Color.PositiveEventValue + "]+15[/color] Initiative"
					}
				];
			}

		});
		this.m.Screens.push({
			ID = "D",
			Text = "[img]gfx/ui/events/event_05.png[/img]You sense it is not the time yet, %slave% still has much to learn and there will always be another opportunity.",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Soon. But not now.",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
			}

		});
	}

	function onUpdateScore()
	{
		if (!this.World.Assets.getOrigin().getID() == "scenario.ret_gladiator")
		{
			return;
		}

		local brothers = this.World.getPlayerRoster().getAll();

		if (brothers.len() < 4)
		{
			return;
		}

		local retiredgladiator_candidates = [];

		foreach( bro in brothers )
		{
			if (bro.getSkills().hasSkill("perk.retglad_mentor"))
			// if (bro.getBackground().getID() == "background.retired_gladiator")
			{
				retiredgladiator_candidates.push(bro);
				break;
			}
		}

		if (retiredgladiator_candidates.len() == 0)
		{
			return;
		}

		local slave_candidates = [];

		foreach( bro in brothers )
		{
			if (bro.getBackground().getID() == "background.slave") //Indebted, both normal, north and south.
			{
				slave_candidates.push(bro);
			}
		}

		if (slave_candidates.len() == 0)
		{
			return;
		}

		this.m.retiredgladiator = retiredgladiator_candidates[this.Math.rand(0, retiredgladiator_candidates.len() - 1)];
		this.m.slave = slave_candidates[this.Math.rand(0, slave_candidates.len() - 1)];
		this.m.Score = (retiredgladiator_candidates.len() + slave_candidates.len()) * 3;
	}

	function onPrepare()
	{
	}

	function onPrepareVariables( _vars )
	{
		_vars.push([
			"retiredgladiator",
			this.m.retiredgladiator.getName()
		]);
		_vars.push([
			"slave",
			this.m.slave.getName()
		]);
	}

	function onClear()
	{
		this.m.retiredgladiator = null;
		this.m.slave = null;
	}

});

