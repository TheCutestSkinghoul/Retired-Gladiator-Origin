this.ret_gladiator_beastslayer_event <- this.inherit("scripts/events/event", {
	m = {
		Dude = null,
	},
	function create()
	{
		this.m.ID = "event.ret_gladiator_beastslayer";
		this.m.Title = "A monster approaches...";
		this.m.Cooldown = 999999.0 * this.World.getTime().SecondsPerDay;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_130.png[/img]As the brush breaks away a large beast strides into view, at first you ready your weapon but quickly notice how the giant wears a full harness and armour, trailing behind it is a wyrm corpse — freshly butchered like a lamb that fell into a pit of wolves. The stranger locks eyes with you. %SPEECH_ON%May the Gilder bless your path%SPEECH_OFF% The giant continues to not break pace as the wyrm is dragged past.\n\n The joyful colossus begins to whistle a tune, but stops a few moments later with a heavy thud of the wyrm’s tail falling to the floor. The living mountain turns in your direction.\n %SPEECH_ON%Wait...I know you!%SPEECH_OFF% You begin to brace against your weapon — not that it would make any difference to the walking wall of meat. The monster stops but a few paces from you and the full extent of the punishment to their body is now evident — their physique is riddled with burns, scars and bitemarks. All of which have healed over like they were simple grazes. The mountain leans in to look at your face. %SPEECH_ON%I knew it — it IS you!%SPEECH_OFF% The colossus seems almost overjoyed as a child would be with a new toy. %SPEECH_ON%You need any beasts slayin\'? I\'ve always wanted to fight with a legend!%SPEECH_OFF%You lower your weapon and prepare for introductions, however the stranger beats you to it. %SPEECH_ON%I come far from the south... I have many names but most know me as...%SPEECH_OFF%The wyrm corpse gurgles in protest as what remains of it\'s lower jaw faintly twitches. The stranger kicks the beast and the gurgling subsides.\n %SPEECH_ON%Don\'t mind him — just a sore loser and all. %SPEECH_OFF% they turn back to you with uncanny speed. %SPEECH_ON%What would you say to a little company? Two strangers in a strange land should draw plenty of crowns and fame!%SPEECH_OFF%",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Some company would be nice.",
					function getResult( _event )
					{
						this.World.getPlayerRoster().add(_event.m.Dude);
						this.World.getTemporaryRoster().clear();
						_event.m.Dude.onHired();
						return 0;
					}

				},
				{
					Text = "I don\'t need your help.",
					function getResult( _event )
					{
						this.World.getTemporaryRoster().clear();
						return 0;
					}

				}
			],
			function start( _event )
			{
				local roster = this.World.getTemporaryRoster();
				_event.m.Dude = roster.create("scripts/entity/tactical/player");
				_event.m.Dude.setStartValuesEx([
					"beastslayer_gladiator_background"
				]);
				_event.m.Dude.getSkills().add(this.new("scripts/skills/perks/perk_retglad_path"));
				_event.m.Dude.getBackground().m.RawDescription = "Forced to fight impossible odds as a child, %name% shocked everyone by slaying hyenas and lindwurms with equal ease. Many flocked to see the giant clad in muscle and scars, making %name% wealthy enough to buy their freedom and travel north. When met with disdain from the northern townships they wandered into the wilderness to find more things to kill — this is when, against all odds, you met and forged a friendship that feels a lifetime in the making.";
				_event.m.Dude.getBackground().buildDescription(true);
				this.Characters.push(_event.m.Dude.getImagePath());
			}

		});
	}

	function onUpdateScore()
	{
		if (this.World.Assets.getOrigin().getID() != "scenario.ret_gladiator")
		{
			return;
		}

		if (this.World.getPlayerRoster().getSize() >= this.World.Assets.getBrothersMax())
		{
			return;
		}

    	local brothers = this.World.getPlayerRoster().getAll();
    	local hasCandidate = false;

    	foreach( bro in brothers )
        {
        	if (bro.getLevel() >= 11 && bro.getBackground().getID() == "background.retired_gladiator")
           {
               hasCandidate = true
           }
    	}

        if (hasCandidate){
        	this.m.Score = 13;
        }
    }

	function onPrepare()
	{
	}

	function onPrepareVariables( _vars )
	{
	}

	function onClear()
	{
		this.m.Dude = null;
	}

});

