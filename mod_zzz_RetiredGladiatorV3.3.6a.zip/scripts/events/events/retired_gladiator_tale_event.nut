this.retired_gladiator_tale_event <- this.inherit("scripts/events/event", {
	m = {
		Gladiator = null
	},
	function create()
	{
		this.m.ID = "event.retired_gladiator_tale";
		this.m.Title = "During camp...";
		this.m.Cooldown = 30.0 * this.World.getTime().SecondsPerDay;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_26.png[/img]As the sun sets on another day, your mind drifts to the past. Another day of trials endured and foes beaten.\n\n %randombro% stares at you intently, studying your every move. At first they ask you questions, probing your knowledge ranging from city state affairs to goat farming. You regale them of a story involving {a goat | a spear | a well | a fortress | the arena | a small farm | a king in the woods | a beast from the sea | a strange object | a hole in the ground} and how you {learned the meaning of life | found a beautiful woman | became a shepard for an afternoon | killed a nomad | killed a nobleman | found a missing slave | killed a giant snake | killed a manhunter | found an oasis | ended up eating too many mushrooms} which led to {getting paid handsomely | being mistaken for a murderer | becoming the proud owner of a chicken | adopting a cat | fleeing the city | leading a pack of wild dogs}. %companyname% sits around the fire as the darkness is repelled at its edges, growing ever more interested at your tale.\n\nEmboldened, your students and ready to get back out there and forge their own tales.",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Killing men and beasts does make for great bedtime stories.",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.Characters.push(_event.m.Gladiator.getImagePath());
				_event.m.Gladiator.improveMood(0.25, "Told one of their stories");

				if (_event.m.Gladiator.getMoodState() >= this.Const.MoodState.Neutral)
				{
					this.List.push({
						id = 10,
						icon = this.Const.MoodStateIcon[_event.m.Gladiator.getMoodState()],
						text = _event.m.Gladiator.getName() + this.Const.MoodStateEvent[_event.m.Gladiator.getMoodState()]
					});
				}

				local brothers = this.World.getPlayerRoster().getAll();
				local xp = this.Math.rand(120, 400)

				foreach( bro in brothers )
				{
					if (bro.getID() == _event.m.Gladiator.getID())
					{
						continue;
					}

					if (this.Math.rand(1, 100) <= 50) //applies to 50% of the party excluding the avatar
					{
						_event.m.bro.addXP(xp);
						_event.m.bro.updateLevel();
						this.List.push({
							id = 16,
							icon = "ui/icons/xp_received.png",
							text = bro.getName() + " gains [color=" + this.Const.UI.Color.PositiveEventValue + "]"+ xp +"[/color] Experience"
						});
					}
				}
			}
		});
	}

	function onUpdateScore()
	{

		if (this.World.getTime().IsDaytime) //if daytime, skip this event
		{
			return;
		}

		local brothers = this.World.getPlayerRoster().getAll();

		if (brothers.len() < 3) //must have at least 3 brothers
		{
			return;
		}

		local candidates = [];

		foreach( bro in brothers )
		{						//must be lvl 8 or higher to trigger
			if (bro.getLevel() >= 8 && bro.getBackground().getID() == "background.ret_gladiator")
			{
				candidates.push(bro);
			}
		}

		if (candidates.len() == 0)
		{
			return;
		}

		this.m.Gladiator = candidates[this.Math.rand(0, candidates.len() - 1)];
		this.m.Score = candidates.len() * 5;
	}

	function onPrepare()
	{
	}

	function onPrepareVariables( _vars )
	{
		_vars.push([
			"retiredgladiator",
			this.m.Gladiator.getNameOnly()
		]);
	}

	function onClear()
	{
		this.m.Gladiator = null;
	}

});
