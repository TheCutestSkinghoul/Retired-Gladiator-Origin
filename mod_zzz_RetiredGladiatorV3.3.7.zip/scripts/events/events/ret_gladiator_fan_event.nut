this.ret_gladiator_fan_event <- this.inherit("scripts/events/event", {
	m = {
		Dude = null,
	},
	function create()
	{
		this.m.ID = "event.ret_gladiator_fan";
		this.m.Title = "Another admirer...";
		this.m.Cooldown = 26.0 * this.World.getTime().SecondsPerDay;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_76.png[/img]While on your travels you notice a figure has been following you for much longer than you would prefer. They haved ducked in and out of your sight in the last town and have been following you for quite some time. You sit down and take a moment to rest. %SPEECH_ON%You can come out now — I won\'t bite if you do!%SPEECH_OFF%\nFrom the corner of your eye a figure comes, approaching you as a child would approach a dying animal. They do not make any sudden movements but instead poke, prod and dissect you with their eyes. %SPEECH_ON%By the Gilder it really is you — standing here...next to me!%SPEECH_OFF%You prepare yourself for the worst. You have met a few admirers in the past but none who would willingly travel so far.\nThe stranger begins to speak again. %SPEECH_ON%Can I follow you around for a bit? I promise I won\'t get in the way and I\'ll do everything you ask me to!%SPEECH_OFF%",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Keep up — and don\'t slow me down.",
					function getResult( _event )
					{
						this.World.getPlayerRoster().add(_event.m.Dude);
						this.World.getTemporaryRoster().clear();
						_event.m.Dude.onHired();
						return 0;
					}

				},
				{
					Text = "I don\'t need your help.",
					function getResult( _event )
					{
						this.World.getTemporaryRoster().clear();
						return 0;
					}

				}
			],

			function start( _event ) // no alchemist. //1 = least likely to generate. //// 1 = high tier melee fighter. // 2 = mid & high tier specialists. // 3 = midtier fighters. // 4 = lowtier.
			{
				local backgrounds = [
					// high tier melee fighter
					[1,	"gladiator_background"],
					// mid & high tier specialists
					[2, "assassin_southern_background"],
					[2, "legend_muladi_background"],
					// midtier fighters
					[3, "nomad_background"],
					[3, "nomad_ranged_background"],
					[3, "caravan_hand_southern_background"],
					// lowtier
					[4, "belly_dancer_background"],
					[4, "legend_qiyan_background"],
					[4, "thief_southern_background"],
					[4, "slave_southern_background"],
					[4, "peddler_southern_background"]		
				];
				local totalWeight = 0;
				local result = []
				foreach (background in backgrounds)
				{
				    totalWeight += background[0];
				}
				local r = this.Math.rand(0, totalWeight);
				foreach (background in backgrounds)
				{
				    r = r - background[0];
				    if (r <= 0)
				    {
				       result.push(background[1])
				      break;
				    }
				}
				local roster = this.World.getTemporaryRoster();
				_event.m.Dude = roster.create("scripts/entity/tactical/player");
				//_event.m.Dude.setStartValuesEx([
				_event.m.Dude.setStartValuesEx(result);
				_event.m.Dude.getBackground().m.RawDescription = "{%name% came far from the south — like many that come from your homeland they share stories of chains, sand, gold and blood. | %name% has had a dull life up until now, their life blemished with safe choices. | After hearing your return and rise to fame they wanted to fight with the \'errant gladiator\', just like they had dreamed about all those years ago watching you in the arena as a child. | %name%\'s face seems familiar, but after a time all the faces begin to shift into one.} {Hailing from in the deepest reaches of the south — and an early conscription into banditry kept it that way as their family lived off the desert until they were old enough to hold a spear. One day the tribe\'s luck ran out in the form of a massacre at the hands of a rival nomad group. Lost and alone %name% escaped and lived in seclusion — right up until you came along. | %name% brags that they are the bastard offspring of the Vizier himself...or maybe it\'s another famous gladiator? The story changes each time you ask. | %name% has always been a troublemaker since their early years — %name% would always steal, fence and haggle whatever they could carry to pay for admission into the arena. They say it was a sight to behold watching you in your early years and is even happier now they have a front row seat without admission to one of the greatest fighters in the south. | %name% was once a slave due to be sold up north as training dummies for noble soldiers looking to drill their recruits better — apparently nothing creates better servitude than killing an unarmed slave. | %name% was once a loyal servant to the Vizier, attenting to his every need. One day they found themselves used as a pawn in an assination attempt gone wrong.} {You swear that you have seen %name% before — perhaps in the prison cells you spent so long in? | %name% has shackle marks around their hands and legs along with a myriad of whip marks across their body. They occasionally mumble something about a goat and butter when you are out of earshot. | They now live a fragment on their previous life. Maybe throwing their lot in with you was their last resort? | Hunted and ashamed, %name% sought you out to try and rekindle a semblence of a life — whatever that\'s supposed to mean...}";
				_event.m.Dude.getBackground().buildDescription(true);
				_event.m.Dude.getSkills().add(this.new("scripts/skills/perks/perk_retglad_path"));
				this.Characters.push(_event.m.Dude.getImagePath());
			}

		});
	}

	function onUpdateScore()
	{
		if (this.World.getPlayerRoster().getSize() >= this.World.Assets.getBrothersMax())
		{
			return;
		}

		if (this.World.Assets.getOrigin().getID() != "scenario.ret_gladiator")
		{
			return;
		}

		this.m.Score = 6;
	}

	// function onBuildPerkTree( _background )
	// {		
	// 	this.addScenarioPerk(_background, this.Const.Perks.PerkDefs.RetGladMentor);
	// }

	function onPrepare()
	{
	}

	function onPrepareVariables( _vars )
	{
	}

	function onClear()
	{
		this.m.Dude = null;
	}

});

